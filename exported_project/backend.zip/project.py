import os

def main():
    print("Executando o projeto final do CS50!")

if __name__ == "__main__":
    main()
    os.system("reflex ")
    os.system("reflex deploy")
