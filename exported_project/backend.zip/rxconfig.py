import reflex as rx

config = rx.Config(
    app_name="final_project",
    export_dir="exported_project"  # Diretório onde o projeto será exportado
)
